<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

UBC students meet new people and go on campus adventures together.

## Metric

Quests matched between two or more students each week
